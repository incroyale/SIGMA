import os
import shutil
import zipfile


def generate_images_for_model(network_url, model_name, flag, class_=None):
    num_images = int(input(f"How many images do you want to generate for {model_name}? "))
    if flag:
        command = f"python generate.py --outdir=output --seeds=0-{num_images - 1} --class={class_} --network={network_url}"
    else:
        command = f"python generate.py --outdir=output --seeds=0-{num_images - 1} --network={network_url}"
    os.system(command)

    # Zip the 'output' folder
    shutil.make_archive("output", "zip", "output")

    # Delete the 'output' folder
    shutil.rmtree("output")


def main():
    pretrained_models = [
        {
            "name": "CIFAR-10",
            # Classes: ['airplanes', 'cars', 'birds', 'cats', 'deer', 'dogs', 'frogs', 'horses', 'ships', 'trucks'],
            "path": "trained_models/cifar10.pkl"
        },
        {
            "name": "Cat",
            "path": "trained_models/afhqcat.pkl"
        },
        {
            "name": "Dog",
            "path": "trained_models/afhqdog.pkl"
        },
        {
            "name": "Wild",
            "path": "trained_models/afhqwild.pkl"
        },
        {
            "name": "FFHQ",
            "path": "trained_models/ffhq.pkl"
        },
        {
            "name": "MetFaces",
            "path": "trained_models/metfaces.pkl"
        },
        {
            "name": "BreCaHAD",
            "path": "trained_models/brecahad.pkl"
        }
    ]

    print("Choose a model to generate images:")
    for idx, model in enumerate(pretrained_models, start=1):
        print(f"{idx}. {model['name']}")

    selected_idx = int(input("Enter the number of the model: "))
    flag = False
    if selected_idx == 1:
        flag = True
        class_ = int(input("Enter the class of the dataset: "))
        selected_model = pretrained_models[selected_idx - 1]
        generate_images_for_model(selected_model["path"], selected_model["name"], flag, class_)

    else:
        selected_model = pretrained_models[selected_idx - 1]
        generate_images_for_model(selected_model["path"], selected_model["name"], flag)


if __name__ == "__main__":
    main()
